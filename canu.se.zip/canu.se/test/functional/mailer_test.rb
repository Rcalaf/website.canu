require 'test_helper'

class MailerTest < ActionMailer::TestCase
  # test "the truth" do
  #   assert true
  # end
end
